
# - INSTRUÇOES GERAIS DO PROJETO

1) O diretório final publicado é Dentistas.com.br/fastbot
2) O nome do arquivo final é index.html
3) O arquivo index.html deve estar na raiz do projeto
4) O projeto deve ser publicado no github pages
5) Always fix the markdown formatting after creating md files
